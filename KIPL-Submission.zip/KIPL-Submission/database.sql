-- ============================================================
-- Employee Attendance Portal — PostgreSQL Schema
-- Khushi Innoventures Private Limited (KIPL Global)
-- ============================================================
-- Run this script to create the full database schema.
-- This also seeds the initial admin and employee accounts.
-- ============================================================

-- Create database (run separately if needed)
-- CREATE DATABASE attendance_portal;
-- \c attendance_portal;

-- ============================================================
-- DROP existing tables (clean slate)
-- ============================================================
DROP TABLE IF EXISTS sessions   CASCADE;
DROP TABLE IF EXISTS leaves     CASCADE;
DROP TABLE IF EXISTS attendance CASCADE;
DROP TABLE IF EXISTS users      CASCADE;

-- ============================================================
-- TABLE: users
-- ============================================================
CREATE TABLE users (
  id                  SERIAL PRIMARY KEY,
  name                VARCHAR(100)  NOT NULL,
  username            VARCHAR(50)   UNIQUE NOT NULL,
  password            VARCHAR(255)  NOT NULL,
  role                VARCHAR(20)   NOT NULL DEFAULT 'employee' CHECK (role IN ('admin','employee')),
  department          VARCHAR(100)  DEFAULT 'General',
  locked              BOOLEAN       DEFAULT FALSE,
  failed_attempts     INTEGER       DEFAULT 0,
  must_change_password BOOLEAN      DEFAULT FALSE,
  created_at          TIMESTAMP     DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- TABLE: attendance
-- ============================================================
CREATE TABLE attendance (
  id           SERIAL PRIMARY KEY,
  user_id      INTEGER       NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  date         DATE          NOT NULL,
  check_in     TIMESTAMP,
  check_out    TIMESTAMP,
  total_hours  DECIMAL(5,2)  DEFAULT 0,
  created_at   TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(user_id, date)
);

-- ============================================================
-- TABLE: leaves
-- ============================================================
CREATE TABLE leaves (
  id          SERIAL PRIMARY KEY,
  user_id     INTEGER       NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  start_date  DATE          NOT NULL,
  end_date    DATE          NOT NULL,
  leave_type  VARCHAR(50)   NOT NULL,
  reason      TEXT,
  status      VARCHAR(20)   DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected')),
  applied_at  TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT valid_dates CHECK (end_date >= start_date)
);

-- ============================================================
-- TABLE: sessions
-- ============================================================
CREATE TABLE sessions (
  id          SERIAL PRIMARY KEY,
  user_id     INTEGER       NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token       TEXT          UNIQUE NOT NULL,
  last_active TIMESTAMP     DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- INDEXES
-- ============================================================
CREATE INDEX idx_attendance_user_id ON attendance(user_id);
CREATE INDEX idx_attendance_date    ON attendance(date);
CREATE INDEX idx_leaves_user_id     ON leaves(user_id);
CREATE INDEX idx_leaves_status      ON leaves(status);
CREATE INDEX idx_sessions_token     ON sessions(token);
CREATE INDEX idx_sessions_user_id   ON sessions(user_id);

-- ============================================================
-- SEED: Initial users
-- Passwords are bcrypt hashed (cost=10)
-- admin123   → $2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy
-- raj123     → $2a$10$rqQ0Af6DxvAHD2Y.Wj2DYee9k.ORN5PFx3mfmKnLJLiDU8yMvijFi
-- sara123    → $2a$10$T.gVl1/BMHq4MZqE7VR7B.GVe7FpLgFHDymCBl.TxVm1Q4TaD8Kja
-- john123    → $2a$10$5EkVZWnJ9sD/M.iWPXu0GeW.DHH7ZJCiKw1lRVHGP0dXWe7KFGLdO
-- priya123   → $2a$10$KcFGxK7ZJnEFX9Vl2uZ5reYWOGHjWCaXUGJo5A8A7Jvk.cRSdYFqG
-- amit123    → $2a$10$M8bFzYJFKr7xr0O4cH5GiehDKxD7f8K7XYL.3VJKoqNZ3pW7r6Pq6
-- ============================================================
INSERT INTO users (name, username, password, role, department) VALUES
  ('Admin User',    'admin',  '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'admin',    'Management'),
  ('Raj Patel',     'raj',    '$2a$10$rqQ0Af6DxvAHD2Y.Wj2DYee9k.ORN5PFx3mfmKnLJLiDU8yMvijFi', 'employee', 'Engineering'),
  ('Sara Khan',     'sara',   '$2a$10$T.gVl1/BMHq4MZqE7VR7B.GVe7FpLgFHDymCBl.TxVm1Q4TaD8Kja', 'employee', 'Design'),
  ('John Mehta',    'john',   '$2a$10$5EkVZWnJ9sD/M.iWPXu0GeW.DHH7ZJCiKw1lRVHGP0dXWe7KFGLdO', 'employee', 'Sales'),
  ('Priya Sharma',  'priya',  '$2a$10$KcFGxK7ZJnEFX9Vl2uZ5reYWOGHjWCaXUGJo5A8A7Jvk.cRSdYFqG', 'employee', 'HR'),
  ('Amit Verma',    'amit',   '$2a$10$M8bFzYJFKr7xr0O4cH5GiehDKxD7f8K7XYL.3VJKoqNZ3pW7r6Pq6', 'employee', 'Engineering');

-- ============================================================
-- SEED: Sample leave requests
-- ============================================================
INSERT INTO leaves (user_id, start_date, end_date, leave_type, reason, status) VALUES
  (2, '2025-04-01', '2025-04-02', 'Sick Leave',   'Fever and cold',      'approved'),
  (3, '2025-04-05', '2025-04-05', 'Casual Leave', 'Personal work',       'approved'),
  (4, '2025-04-10', '2025-04-11', 'Casual Leave', 'Family function',     'pending'),
  (5, '2025-04-15', '2025-04-15', 'Sick Leave',   'Doctor appointment',  'pending'),
  (6, '2025-03-20', '2025-03-21', 'Annual Leave', 'Vacation',            'rejected');

-- ============================================================
-- Verify
-- ============================================================
SELECT 'Tables created successfully' AS status;
SELECT COUNT(*) AS user_count FROM users;
