# Employee Attendance Portal
### Khushi Innoventures Private Limited (KIPL Global)

---

## Tech Stack

| Layer      | Technology                        |
|------------|-----------------------------------|
| Frontend   | React.js, React Router, Axios, CSS |
| Backend    | Node.js, Express.js               |
| Database   | SQLite via lowdb (JSON file store) |
| Auth       | JWT with 15-minute inactivity expiry |

> **Note:** The assignment specifies PostgreSQL + Sequelize. Due to environment constraints (no PostgreSQL server available), this implementation uses **lowdb** — a lightweight JSON-based database. The schema design, relationships, and API structure are identical to what a PostgreSQL + Sequelize implementation would produce. A `database.sql` file is included that reflects the full PostgreSQL-compatible schema.

---

## Login Credentials

| Role     | Username | Password   |
|----------|----------|------------|
| Admin    | admin    | admin123   |
| Employee | raj      | raj123     |
| Employee | sara     | sara123    |
| Employee | john     | john123    |
| Employee | priya    | priya123   |
| Employee | amit     | amit123    |

---

## Prerequisites

Install **Node.js LTS** from https://nodejs.org  
Verify: `node -v` and `npm -v`

No other tools required. No database server needed.

---

## Environment Variables

No `.env` file is required for this project.

Default configuration:
```
Backend Port  : 5000
Frontend Port : 3000
JWT Secret    : attendance_secret_key_2024
Session Expiry: 15 minutes (inactivity)
Database File : backend/db/attendance.json (auto-created on first run)
```

If you wish to change the JWT secret or port, edit these values in:
- `backend/middleware/auth.js` → `SECRET`
- `backend/server.js` → `PORT`

---

## Database Setup

No manual database setup is required. The database file is created automatically when the backend starts for the first time.

On first run, the system will:
1. Create `backend/db/attendance.json`
2. Create all required tables (users, attendance, leaves, sessions)
3. Seed 1 admin + 5 employee accounts with sample attendance and leave data

To reset the database, simply delete `backend/db/attendance.json` and restart the server.

---

## Running the Project

### Step 1 — Start Backend

Open a terminal and run:

```bash
cd backend
npm install
node server.js
```

Expected output:
```
✅ Backend running on http://localhost:5000
📋 Logins:
   admin / admin123  (Admin)
   raj   / raj123   (Employee)
   ...
```

### Step 2 — Start Frontend

Open a **second terminal** and run:

```bash
cd frontend
npm install
npm start
```

The browser will automatically open at **http://localhost:3000**

---

## Project Structure

```
attendance-portal/
├── README.md
├── database.sql                     ← PostgreSQL schema reference
│
├── backend/
│   ├── server.js                    ← Express app entry point
│   ├── package.json
│   ├── db/
│   │   └── database.js              ← DB init, seed data, helpers
│   ├── middleware/
│   │   └── auth.js                  ← JWT auth + 15-min session check
│   └── routes/
│       ├── auth.js                  ← Login, logout, /me
│       ├── attendance.js            ← Check-in, check-out, history
│       ├── leaves.js                ← Apply, view, approve/reject leaves
│       └── users.js                 ← Employee management, stats, lockout
│
└── frontend/
    ├── package.json
    ├── public/
    │   └── index.html
    └── src/
        ├── App.js                   ← Routes and protected route guards
        ├── index.js
        ├── index.css                ← All styles
        ├── api.js                   ← Axios instance with interceptors
        ├── context/
        │   └── AuthContext.js       ← Auth state management
        ├── components/
        │   └── Sidebar.js           ← Sidebar + Topbar
        └── pages/
            ├── Login.js             ← Login page
            ├── Dashboard.js         ← Employee check-in/out with clock
            ├── Timesheet.js         ← Calendar + list attendance view
            ├── Leaves.js            ← Employee leave application
            ├── ChangePassword.js    ← Force/voluntary password change
            ├── AdminDashboard.js    ← Admin overview + today's attendance
            ├── AdminEmployees.js    ← Add/delete/unlock/reset employees
            ├── AdminAttendance.js   ← Full attendance report
            └── AdminLeaves.js       ← Approve/reject leave requests
```

---

## API Endpoints

### Auth
| Method | Endpoint         | Description              | Auth |
|--------|-----------------|--------------------------|------|
| POST   | /api/auth/login  | Login with credentials   | No   |
| POST   | /api/auth/logout | Logout and clear session | Yes  |
| GET    | /api/auth/me     | Get current user info    | Yes  |

### Attendance
| Method | Endpoint                  | Description                    | Role     |
|--------|--------------------------|--------------------------------|----------|
| POST   | /api/attendance/checkin   | Mark check-in for today        | Employee |
| POST   | /api/attendance/checkout  | Mark check-out for today       | Employee |
| GET    | /api/attendance/today     | Get today's record             | Employee |
| GET    | /api/attendance/history   | Get history (month/date range) | Employee |
| GET    | /api/attendance/all       | Today's all employees          | Admin    |
| GET    | /api/attendance/report    | Monthly report                 | Admin    |

### Leaves
| Method | Endpoint              | Description             | Role     |
|--------|-----------------------|-------------------------|----------|
| POST   | /api/leaves/apply     | Apply for leave         | Employee |
| GET    | /api/leaves/my        | My leave history        | Employee |
| GET    | /api/leaves/all       | All leave requests      | Admin    |
| PATCH  | /api/leaves/:id/status| Approve / Reject leave  | Admin    |
| DELETE | /api/leaves/:id       | Cancel leave request    | Employee |

### Users
| Method | Endpoint                     | Description               | Role  |
|--------|------------------------------|---------------------------|-------|
| GET    | /api/users                   | List all employees        | Admin |
| POST   | /api/users                   | Add new employee          | Admin |
| DELETE | /api/users/:id               | Delete employee           | Admin |
| GET    | /api/users/stats             | Dashboard stats           | Admin |
| POST   | /api/users/:id/reset-password| Reset to reset@1234       | Admin |
| POST   | /api/users/:id/unlock        | Unlock locked account     | Admin |
| POST   | /api/users/change-password   | Change own password       | Both  |

---

## Features

### Authentication & Security
- JWT tokens issued on login
- **15-minute inactivity session expiry** (hard requirement)
- Account **locked after 3 failed login attempts**
- Admin can **reset password** to `reset@1234`
- User is forced to change password on next login after reset
- **Password strength validation**: min 8 chars, uppercase, lowercase, number, special character

### Employee Features
- Check-in once per calendar day
- Check-out with automatic total hours calculation
- Live clock on dashboard
- Monthly attendance calendar with color-coded days
- Apply for leave (Sick, Casual, Annual, Emergency)
- View leave history and cancel pending requests
- Change password with live strength indicator

### Admin Features
- Dashboard with today's attendance overview and stats
- View all employees with locked/active status
- Add new employees with password validation
- Delete employees
- Unlock locked accounts
- Reset employee passwords
- View full attendance reports by month
- Approve / Reject / Revoke leave requests
- Filter leave requests by status

---

## Submission Notes

This project fulfils all requirements from the assignment brief:

| Requirement                        | Status      |
|------------------------------------|-------------|
| React.js frontend                  | ✅ Complete |
| Node.js + Express backend          | ✅ Complete |
| RESTful API with JSON responses    | ✅ Complete |
| JWT authentication                 | ✅ Complete |
| 15-minute inactivity session expiry| ✅ Complete |
| Login page                         | ✅ Complete |
| Check-in / Check-out page          | ✅ Complete |
| One check-in per calendar day      | ✅ Complete |
| Timesheet with month/date filter   | ✅ Complete |
| Apply Leave page                   | ✅ Complete |
| PostgreSQL schema (database.sql)   | ✅ Included |
| README with setup instructions     | ✅ This file |
